package com.example.hackathon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    Intent intent;
    TextView tvScore,tvAudioScore,tvVisualScore,tvKinestheticScore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        intent=getIntent();

        tvScore=findViewById(R.id.tvScore);
        tvAudioScore=findViewById(R.id.tvAudioScore);
        tvVisualScore=findViewById(R.id.tvVisualScore);
        tvKinestheticScore=findViewById(R.id.tvKinestheticScore);

        int AudioValue=Integer.parseInt(intent.getStringExtra("auditary"));
        int VisualValue=Integer.parseInt(intent.getStringExtra("Visual"));
        int KinestheticValue=Integer.parseInt(intent.getStringExtra("kinesthetic"));
        int totalScore=AudioValue+VisualValue+KinestheticValue;
        int AudioPercent=(int)(AudioValue/totalScore)*100;
        int VisualPercent=(int)(VisualValue/totalScore)*100;
        int KinestheticPercent=(int)(KinestheticValue/totalScore)*100;

        int maxScore=Math.max(AudioValue,Math.max(VisualValue,KinestheticValue));
        if(maxScore==MyApplicationClass.audio)
            tvScore.setText("Auditary");
        if(maxScore==MyApplicationClass.visual)
            tvScore.setText("Visual");
        if(maxScore==MyApplicationClass.kinesthetic)
            tvScore.setText("Kinesthetic");





        tvAudioScore.setText("Percentage match for Auditory Learning Style: "+AudioPercent);
        tvVisualScore.setText("Percentage match for Visual Learning Style: "+VisualPercent);
        tvKinestheticScore.setText("Percentage match for Kinesthetic Learning Style: "+KinestheticPercent);




    }
}
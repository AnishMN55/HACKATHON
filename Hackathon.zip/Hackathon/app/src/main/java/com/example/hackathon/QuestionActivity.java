package com.example.hackathon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class QuestionActivity extends AppCompatActivity {

    Intent intent;
    TextView tvQuestion;
    EditText etMarks;
    Button btnNext;
    String age,qualification;
    static int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        intent=getIntent();
        age=intent.getStringExtra("age");
        qualification=intent.getStringExtra("qualification");
        etMarks=findViewById(R.id.etMarks);
        btnNext=findViewById(R.id.btnNext);

        tvQuestion=findViewById(R.id.tvQuestion);

        loadQuestion();
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int value=Integer.parseInt(etMarks.getText().toString());
                calculate(value);
                if(value<=0 || value>=11 ) {
                    Toast.makeText(QuestionActivity.this, "Please enter value between 1-10", Toast.LENGTH_SHORT).show();
                }
                else if(i==15) {
                    int maxValue=Math.max(MyApplicationClass.audio,Math.max(MyApplicationClass.visual,MyApplicationClass.kinesthetic));
                    Intent intent1=new Intent(QuestionActivity.this,ResultActivity.class);
                    intent1.putExtra("auditary",MyApplicationClass.audio);
                    intent1.putExtra("Visual",MyApplicationClass.visual);
                    intent1.putExtra("kinesthetic",MyApplicationClass.kinesthetic);
                    intent1.putExtra("maxValue",maxValue);
                    startActivity(intent1);
                }
                else
                loadQuestion();

            }
        });
    }
    public void loadQuestion()
    {
        etMarks.setText(0+"");
        if(age.equals("5"))
        {
            if(qualification.equals("Teacher"))
            {
                tvQuestion.setText(MyApplicationClass.teacher5_10s.get(i++).feature);
            }
            else if (qualification.equals("Parent"))
            {
                tvQuestion.setText(MyApplicationClass.parent5_10s.get(i++).feature);
            }
        }

        else
        {
            if(qualification.equals("Teacher"))
            {
                tvQuestion.setText(MyApplicationClass.teacher11s.get(i++).feature);
            }
            else if (qualification.equals("Parent"))
            {
                tvQuestion.setText(MyApplicationClass.parent11s.get(i++).feature);
            }
            else
            {
                tvQuestion.setText(MyApplicationClass.student11s.get(i++).feature);
            }
        }
    }
    public void calculate(int value)
    {
        if(value<=0 || value>=11 )
            return;

        if(i<=5)
            MyApplicationClass.audio+=value;
        else if(i<=10)
            MyApplicationClass.visual+=value;
        else
            MyApplicationClass.kinesthetic+=value;

    }
}
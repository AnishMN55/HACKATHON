package com.example.hackathon;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etStudentName;
    Button btn5_10,btn11_above;
    Button btnParent,btnStudent,btnTeacher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etStudentName=findViewById(R.id.etStudentName);
        btn5_10=findViewById(R.id.btn5_10);
        btn11_above=findViewById(R.id.btn11_above);

        btn5_10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etStudentName.getText().length()==0)
                    Toast.makeText(MainActivity.this, "Please enter the Students name", Toast.LENGTH_SHORT).show();
                else
                {
                    showAlert1();
                }
            }
        });

        btn11_above.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etStudentName.getText().length()==0)
                    Toast.makeText(MainActivity.this, "Please enter the Students name", Toast.LENGTH_SHORT).show();
                else
                {
                    showAlert2();
                }
            }
        });

    }
    public void showAlert1()
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        View view= LayoutInflater.from(this).inflate(R.layout.alert_teacher_student,null);
        builder.setView(view);
        AlertDialog dialog=builder.create();
        dialog.show();

        btnTeacher=view.findViewById(R.id.btnTeacher);
        btnStudent=view.findViewById(R.id.btnStudent);
        btnParent=view.findViewById(R.id.btnParent);

        btnStudent.setVisibility(View.GONE);


        btnTeacher.setOnClickListener(v->
        {
            Toast.makeText(this, "You are a teacher", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainActivity.this,QuestionActivity.class);
            intent.putExtra("age","5");
            intent.putExtra("qualification","Teacher");
            startActivity(intent);
        });

        btnParent.setOnClickListener(v->
        {
            Toast.makeText(this, "You are a Parent", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainActivity.this,QuestionActivity.class);
            intent.putExtra("age","5");
            intent.putExtra("qualification","Parent");
            startActivity(intent);
        });
    }

    public void showAlert2()
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        View view= LayoutInflater.from(this).inflate(R.layout.alert_teacher_student,null);
        builder.setView(view);
        AlertDialog dialog=builder.create();
        dialog.show();

        btnTeacher=view.findViewById(R.id.btnTeacher);
        btnStudent=view.findViewById(R.id.btnStudent);
        btnParent=view.findViewById(R.id.btnParent);


        btnTeacher.setOnClickListener(v->
        {
            Toast.makeText(this, "You are a teacher", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainActivity.this,QuestionActivity.class);
            intent.putExtra("age","11");
            intent.putExtra("qualification","Teacher");
            startActivity(intent);
        });

        btnStudent.setOnClickListener(v->
        {
            Toast.makeText(this, "You are a Student", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainActivity.this,QuestionActivity.class);
            intent.putExtra("age","11");
            intent.putExtra("qualification","Student");
            startActivity(intent);
        });

        btnParent.setOnClickListener(v->
        {
            Toast.makeText(this, "You are a Parent", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainActivity.this,QuestionActivity.class);
            intent.putExtra("age","11");
            intent.putExtra("qualification","Parent");
            startActivity(intent);
        });
    }
}
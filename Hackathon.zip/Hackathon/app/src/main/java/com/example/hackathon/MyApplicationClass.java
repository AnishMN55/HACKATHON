package com.example.hackathon;

import android.app.Application;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyApplicationClass extends Application {
    static int visual=0;
    static int audio=0;
    static int kinesthetic=0;

    static ArrayList<Teacher5_10> teacher5_10s=new ArrayList<>();
    static ArrayList<Parent5_10> parent5_10s=new ArrayList<>();
    static ArrayList<Teacher11> teacher11s=new ArrayList<>();
    static ArrayList<Parent11> parent11s=new ArrayList<>();
    static ArrayList<Student11> student11s=new ArrayList<>();


    @Override
    public void onCreate() {
        super.onCreate();

        //teacher 5-10
        teacher5_10s.add(new Teacher5_10("Student prefers verbal praises from teacher"));
        teacher5_10s.add(new Teacher5_10("Student like to talk a lot"));
        teacher5_10s.add(new Teacher5_10("Student cannot concentrate when noisy"));
        teacher5_10s.add(new Teacher5_10("Student Obeys oral instructions from teacher"));
        teacher5_10s.add(new Teacher5_10("Student cannot wait to get a chance to talk"));
        teacher5_10s.add(new Teacher5_10("Student remembers better by seeing charts and diagrams"));
        teacher5_10s.add(new Teacher5_10("Student chooses art over music"));
        teacher5_10s.add(new Teacher5_10("Student has a good handwriting!"));
        teacher5_10s.add(new Teacher5_10("Student enjoys maps,pictures, diagram and colors"));
        teacher5_10s.add(new Teacher5_10("Student is a good speller"));
        teacher5_10s.add(new Teacher5_10("Student enjoys learning outside the classroom"));
        teacher5_10s.add(new Teacher5_10("Student enjoys physical games and activities over classroom learning"));
        teacher5_10s.add(new Teacher5_10("Student is unlikely to forget what they learn!"));
        teacher5_10s.add(new Teacher5_10("Student learns with fun"));
        teacher5_10s.add(new Teacher5_10("Student loves to experiment and test things"));


        parent5_10s.add(new Parent5_10("How much does your child enjoys music"));
        parent5_10s.add(new Parent5_10("How much is your child good at story telling"));
        parent5_10s.add(new Parent5_10("How well yur child indicate emotion through tone,pitch and volume of voice"));
        parent5_10s.add(new Parent5_10("How good is your child at reciting information"));
        parent5_10s.add(new Parent5_10("Does your child read with whispering lip movements"));
        parent5_10s.add(new Parent5_10("How well your child remember faces?"));
        parent5_10s.add(new Parent5_10("How good is your child at facial expressions to share the emotions?"));
        parent5_10s.add(new Parent5_10("How neatly does your child dress up to appear"));
        parent5_10s.add(new Parent5_10("Child often takes longer time to recall information as they replay scenarios in their mind."));
        parent5_10s.add(new Parent5_10("Child answers with one word or totally incomplete answers"));
        parent5_10s.add(new Parent5_10("Child loves to solve more puzzels"));
        parent5_10s.add(new Parent5_10("Child often plays with keys or coins in pocket."));
        parent5_10s.add(new Parent5_10("Child likes to hold and touch things rather than seeing to learn."));
        parent5_10s.add(new Parent5_10("Child uses body movements to interact"));
        parent5_10s.add(new Parent5_10("Child prefers physical activities to learn something."));


        //teacher 11 above
        teacher11s.add(new Teacher11("Student prefers verbal praises from teacher"));
        teacher11s.add(new Teacher11("Student always finds a study buddy"));
        teacher11s.add(new Teacher11("How good is the student at explaining ideas out loud"));
        teacher11s.add(new Teacher11("Student memorizes the information sequentially"));
        teacher11s.add(new Teacher11("Student actively participates in the classroom dicussions"));
        teacher11s.add(new Teacher11("Remembers better by seeing charts and diagrams"));
        teacher11s.add(new Teacher11("Student frequently day dreams during lectures and class"));
        teacher11s.add(new Teacher11("Student gets distracted and starts a conversation during the class"));
        teacher11s.add(new Teacher11("Student prefers to take notes neatly"));
        teacher11s.add(new Teacher11("Student may misunderstand the instructions presented verbally"));
        teacher11s.add(new Teacher11("Student gets distracted and starts a conversation during the class"));
        teacher11s.add(new Teacher11("Student learns skills better than concepts"));
        teacher11s.add(new Teacher11("Student is better at innovation than implementation"));
        teacher11s.add(new Teacher11("Student learns with fun"));
        teacher11s.add(new Teacher11("Student loves to experiment and test things"));



//        parent 11 above
        parent11s.add(new Parent11("Child talks to himself / herself quite often"));
        parent11s.add(new Parent11("Child reads with whispering lip movements"));
        parent11s.add(new Parent11("Child often sings or humms music"));
        parent11s.add(new Parent11("Child expresses emotions through talk"));
        parent11s.add(new Parent11("Child has outgoing nature"));
        parent11s.add(new Parent11("Child is not really talkative"));
        parent11s.add(new Parent11("Child stares when angry and beams when happy"));
        parent11s.add(new Parent11("Child is good at art than music"));
        parent11s.add(new Parent11("Child prefers to demonstrate than telling or reporting"));
        parent11s.add(new Parent11("Child may think in pictures and learns best from visual displays"));
        parent11s.add(new Parent11("Child performs physical activities to learn something"));
        parent11s.add(new Parent11("Child walks while studying"));
        parent11s.add(new Parent11("Child break things apart in order to learn more about them"));
        parent11s.add(new Parent11("Child prefers to eat snacks during studies"));
        parent11s.add(new Parent11("Child thinks innovatively and never gets bored of learning"));


//        student 11 above
        student11s.add(new Student11("I am good at explaining ideas out loud"));
        student11s.add(new Student11("I am affective member of study groups"));
        student11s.add(new Student11("I am unafraid to speak up in class"));
        student11s.add(new Student11("I am quite active at classroom discussions"));
        student11s.add(new Student11("I memorize concepts sequentially"));
        student11s.add(new Student11("I plan things in advance and organising writing things down"));
        student11s.add(new Student11("I prefer silent rooms over study groups"));
        student11s.add(new Student11("I visualise picture to remember"));
        student11s.add(new Student11("I dislike to speak infront of the class"));
        student11s.add(new Student11("A word sound or smell causes recall and mental wandering"));
        student11s.add(new Student11("I take frequent study breaks to focus"));
        student11s.add(new Student11("I prefer pictorial notes making over gathering information"));
        student11s.add(new Student11("I use actions and fingers to memorise"));
        student11s.add(new Student11("I feel trouble sitting still to sit over a place for a long time"));
        student11s.add(new Student11("I learn skills better than concepts"));


    }





}
class Teacher5_10
{
    String feature;
    public Teacher5_10(String feature)
    {
        this.feature=feature;
    }
}

class Parent5_10
{
    String feature;
    public Parent5_10(String feature)
    {
        this.feature=feature;
    }
}

class Teacher11
{
    String feature;
    public Teacher11(String feature)
    {
        this.feature=feature;
    }
}
class Parent11
{
    String feature;
    public Parent11(String feature)
    {
        this.feature=feature;
    }
}
class Student11
{
    String feature;
    public Student11(String feature)
    {
        this.feature=feature;
    }
}